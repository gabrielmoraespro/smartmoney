import { useEffect, useState, useMemo, useCallback, useRef } from 'react'
import { supabase } from '../../lib/supabase'
import type { Transaction, Account } from '../../lib/types'
import {
  Search, X, ChevronDown, ArrowUpRight, ArrowDownRight,
  Download, ChevronLeft, ChevronRight, Eye, EyeOff,
  Calendar, SlidersHorizontal, MoreVertical, TrendingUp,
  TrendingDown, Hash, DollarSign, Filter, RefreshCw
} from 'lucide-react'

// ─── Types & Constants ────────────────────────────────────────────────────────
const LIMIT = 25

type SortKey = 'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'
type TypeFilter = 'all' | 'credit' | 'debit'
type PeriodPreset = 'this_month' | 'last_month' | 'last_30' | 'last_90' | 'last_6m' | 'this_year' | 'last_year' | 'custom'

const PERIOD_LABELS: Record<PeriodPreset, string> = {
  this_month: 'Este mês', last_month: 'Mês passado', last_30: 'Últimos 30 dias',
  last_90: 'Últimos 90 dias', last_6m: 'Últimos 6 meses', this_year: 'Este ano',
  last_year: 'Ano passado', custom: 'Personalizado',
}

const SORT_LABELS: Record<SortKey, string> = {
  date_desc: 'Data (mais recente)', date_asc: 'Data (mais antiga)',
  amount_desc: 'Valor (maior)', amount_asc: 'Valor (menor)',
}

const CATEGORY_COLORS: Record<string, string> = {
  'Alimentação': '#f59e0b', 'Supermercado': '#10b981', 'Transporte': '#60a5fa',
  'Moradia': '#a78bfa', 'Saúde': '#f472b6', 'Lazer': '#34d399',
  'Educação': '#fbbf24', 'Vestuário': '#818cf8', 'Outros': '#6b7280',
  'Delivery de alimentos': '#fb923c', 'Restaurantes': '#f87171',
  'Farmácia': '#4ade80', 'Combustível': '#38bdf8',
}

const getCatColor = (cat?: string) => {
  if (!cat) return '#6b7280'
  for (const [key, color] of Object.entries(CATEGORY_COLORS)) {
    if (cat.toLowerCase().includes(key.toLowerCase())) return color
  }
  return '#6b7280'
}

const fmt = (v: number) => Math.abs(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const fmtShort = (v: number) => v >= 1000 ? `R$${(v / 1000).toFixed(1)}k` : `R$${v.toFixed(0)}`

function getPeriodDates(preset: PeriodPreset, customStart?: string, customEnd?: string): { from: string; to: string } {
  const now = new Date()
  const iso = (d: Date) => d.toISOString().substring(0, 10)
  switch (preset) {
    case 'this_month': return { from: iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: iso(now) }
    case 'last_month': return { from: iso(new Date(now.getFullYear(), now.getMonth() - 1, 1)), to: iso(new Date(now.getFullYear(), now.getMonth(), 0)) }
    case 'last_30': { const d = new Date(now); d.setDate(d.getDate() - 29); return { from: iso(d), to: iso(now) } }
    case 'last_90': { const d = new Date(now); d.setDate(d.getDate() - 89); return { from: iso(d), to: iso(now) } }
    case 'last_6m': { const d = new Date(now); d.setMonth(d.getMonth() - 6); return { from: iso(d), to: iso(now) } }
    case 'this_year': return { from: `${now.getFullYear()}-01-01`, to: iso(now) }
    case 'last_year': return { from: `${now.getFullYear() - 1}-01-01`, to: `${now.getFullYear() - 1}-12-31` }
    case 'custom': return { from: customStart ?? iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: customEnd ?? iso(now) }
  }
}

// ─── Dropdown Component ───────────────────────────────────────────────────────
function Dropdown({ label, icon, children }: { label: string; icon?: React.ReactNode; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button onClick={() => setOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', fontSize: 12, fontWeight: 500, cursor: 'pointer', whiteSpace: 'nowrap' }}>
        {icon}{label}<ChevronDown style={{ width: 12, height: 12, color: '#8b949e' }} />
      </button>
      {open && (
        <div onClick={() => setOpen(false)} style={{ position: 'absolute', top: '100%', left: 0, marginTop: 4, zIndex: 50, background: '#161b22', border: '1px solid #30363d', borderRadius: 10, minWidth: 190, boxShadow: '0 8px 24px rgba(0,0,0,0.4)', overflow: 'hidden' }}>
          {children}
        </div>
      )}
    </div>
  )
}

function DropdownItem({ label, active, onClick }: { label: string; active?: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ display: 'block', width: '100%', textAlign: 'left', padding: '9px 14px', background: active ? '#238636' : 'transparent', color: active ? '#fff' : '#e6edf3', fontSize: 13, cursor: 'pointer', border: 'none' }}
      onMouseEnter={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = '#21262d' }}
      onMouseLeave={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'transparent' }}>
      {label}
    </button>
  )
}

function StatCard({ label, value, color, icon }: { label: string; value: string; color: string; icon: React.ReactNode }) {
  return (
    <div style={{ background: '#0d1117', border: '1px solid #21262d', borderRadius: 14, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 40, height: 40, borderRadius: 10, background: `${color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color }}>
        {icon}
      </div>
      <div>
        <p style={{ color: '#484f58', fontSize: 11, marginBottom: 3 }}>{label}</p>
        <p style={{ color: '#e6edf3', fontWeight: 700, fontSize: 18 }}>{value}</p>
      </div>
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function Transacoes() {
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([])
  const [accounts, setAccounts] = useState<Account[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all')
  const [accountFilter, setAccountFilter] = useState<string>('all')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [sortKey, setSortKey] = useState<SortKey>('date_desc')
  const [period, setPeriod] = useState<PeriodPreset>('this_month')
  const [customStart, setCustomStart] = useState('')
  const [customEnd, setCustomEnd] = useState('')
  const [showCustom, setShowCustom] = useState(false)
  const [showValues, setShowValues] = useState(true)
  const [page, setPage] = useState(0)
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)

  const loadData = useCallback(async (isRefresh = false) => {
    isRefresh ? setRefreshing(true) : setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const [txRes, accRes] = await Promise.all([
        supabase.from('transactions').select('*').eq('user_id', user.id).order('date', { ascending: false }).limit(1000),
        supabase.from('accounts').select('*').eq('user_id', user.id).eq('is_active', true),
      ])
      setAllTransactions((txRes.data ?? []) as Transaction[])
      setAccounts((accRes.data ?? []) as Account[])
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const { from, to } = useMemo(() => getPeriodDates(period, customStart, customEnd), [period, customStart, customEnd])

  const categories = useMemo(() => {
    const set = new Set(allTransactions.map(t => t.category ?? 'Outros').filter(Boolean))
    return Array.from(set).sort()
  }, [allTransactions])

  const accountsMap = useMemo(() =>
    accounts.reduce((m, a) => { m[a.id] = a.bank_name; return m }, {} as Record<string, string>),
    [accounts])

  const filtered = useMemo(() => {
    let txs = allTransactions.filter(t => t.date >= from && t.date <= to)
    if (typeFilter !== 'all') txs = txs.filter(t => t.type === typeFilter)
    if (accountFilter !== 'all') txs = txs.filter(t => t.account_id === accountFilter)
    if (categoryFilter !== 'all') txs = txs.filter(t => (t.category ?? 'Outros') === categoryFilter)
    if (search.trim()) txs = txs.filter(t => t.description.toLowerCase().includes(search.toLowerCase()))
    switch (sortKey) {
      case 'date_desc': txs.sort((a, b) => b.date.localeCompare(a.date)); break
      case 'date_asc': txs.sort((a, b) => a.date.localeCompare(b.date)); break
      case 'amount_desc': txs.sort((a, b) => Math.abs(Number(b.amount)) - Math.abs(Number(a.amount))); break
      case 'amount_asc': txs.sort((a, b) => Math.abs(Number(a.amount)) - Math.abs(Number(b.amount))); break
    }
    return txs
  }, [allTransactions, from, to, typeFilter, accountFilter, categoryFilter, search, sortKey])

  const stats = useMemo(() => {
    const income = filtered.filter(t => t.type === 'credit').reduce((s, t) => s + Math.abs(Number(t.amount)), 0)
    const expense = filtered.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(Number(t.amount)), 0)
    return { income, expense, balance: income - expense, count: filtered.length }
  }, [filtered])

  const paginated = useMemo(() => filtered.slice(page * LIMIT, (page + 1) * LIMIT), [filtered, page])
  const totalPages = Math.ceil(filtered.length / LIMIT)

  const grouped = useMemo(() => {
    const map: Record<string, Transaction[]> = {}
    paginated.forEach(t => { if (!map[t.date]) map[t.date] = []; map[t.date].push(t) })
    return Object.entries(map).sort((a, b) => sortKey === 'date_asc' ? a[0].localeCompare(b[0]) : b[0].localeCompare(a[0]))
  }, [paginated, sortKey])

  const hasFilters = typeFilter !== 'all' || accountFilter !== 'all' || categoryFilter !== 'all' || search.trim() !== ''

  const exportCSV = () => {
    const rows = [['Data', 'Descrição', 'Categoria', 'Conta', 'Tipo', 'Valor']]
    filtered.forEach(t => rows.push([t.date, t.description, t.category ?? 'Outros', accountsMap[t.account_id] ?? '', t.type, String(Math.abs(Number(t.amount)))]))
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    a.download = `transacoes_${from}_${to}.csv`; a.click()
  }

  if (loading) return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 4 }}>
      {[...Array(6)].map((_, i) => <div key={i} style={{ height: 52, background: '#161b22', borderRadius: 12, opacity: 1 - i * 0.12 }} />)}
    </div>
  )

  return (
    <div style={{ color: '#e6edf3', fontFamily: 'system-ui, sans-serif' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 700, margin: 0 }}>Transações</h1>
          <p style={{ color: '#484f58', fontSize: 13, marginTop: 4 }}>{filtered.length} registros · {PERIOD_LABELS[period]}</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => loadData(true)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#8b949e', fontSize: 12, cursor: 'pointer' }}>
            <RefreshCw style={{ width: 13, height: 13, animation: refreshing ? 'spin 1s linear infinite' : 'none' }} />
            Atualizar
          </button>
          <button onClick={() => setShowValues(v => !v)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#8b949e', fontSize: 12, cursor: 'pointer' }}>
            {showValues ? <EyeOff style={{ width: 13, height: 13 }} /> : <Eye style={{ width: 13, height: 13 }} />}
            {showValues ? 'Ocultar' : 'Mostrar'}
          </button>
          <button onClick={exportCSV} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', background: '#238636', border: '1px solid #2ea043', borderRadius: 8, color: '#fff', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
            <Download style={{ width: 13, height: 13 }} />
            Exportar CSV
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        <StatCard label="Total de registros" value={String(stats.count)} color="#58a6ff" icon={<Hash style={{ width: 18, height: 18 }} />} />
        <StatCard label="Receitas" value={showValues ? fmtShort(stats.income) : '••••'} color="#10b981" icon={<TrendingUp style={{ width: 18, height: 18 }} />} />
        <StatCard label="Despesas" value={showValues ? fmtShort(stats.expense) : '••••'} color="#ef4444" icon={<TrendingDown style={{ width: 18, height: 18 }} />} />
        <StatCard label="Saldo" value={showValues ? fmtShort(stats.balance) : '••••'} color={stats.balance >= 0 ? '#4ade80' : '#f87171'} icon={<DollarSign style={{ width: 18, height: 18 }} />} />
      </div>

      {/* Toolbar */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200, maxWidth: 300 }}>
          <Search style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, color: '#484f58' }} />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(0) }} placeholder="Buscar transações..."
            style={{ width: '100%', padding: '8px 32px', background: '#161b22', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
          {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#484f58' }}><X style={{ width: 14, height: 14 }} /></button>}
        </div>

        {/* Period dropdown */}
        <div style={{ position: 'relative' }}>
          <Dropdown label={PERIOD_LABELS[period]} icon={<Calendar style={{ width: 13, height: 13, color: '#8b949e' }} />}>
            {(Object.keys(PERIOD_LABELS) as PeriodPreset[]).filter(k => k !== 'custom').map(k => (
              <DropdownItem key={k} label={PERIOD_LABELS[k]} active={period === k} onClick={() => { setPeriod(k); setShowCustom(false); setPage(0) }} />
            ))}
            <div style={{ borderTop: '1px solid #30363d', margin: '4px 0' }} />
            <DropdownItem label="Personalizado..." active={period === 'custom'} onClick={() => { setPeriod('custom'); setShowCustom(true) }} />
          </Dropdown>
          {showCustom && (
            <div style={{ position: 'absolute', top: '100%', left: 0, marginTop: 4, zIndex: 100, background: '#161b22', border: '1px solid #30363d', borderRadius: 12, padding: 16, minWidth: 240, boxShadow: '0 8px 24px rgba(0,0,0,0.5)' }}>
              <p style={{ color: '#8b949e', fontSize: 12, marginBottom: 10 }}>Período personalizado</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div><label style={{ color: '#484f58', fontSize: 11, display: 'block', marginBottom: 4 }}>De</label>
                  <input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)} style={{ width: '100%', padding: '7px 10px', background: '#0d1117', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', fontSize: 13, boxSizing: 'border-box' }} /></div>
                <div><label style={{ color: '#484f58', fontSize: 11, display: 'block', marginBottom: 4 }}>Até</label>
                  <input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)} style={{ width: '100%', padding: '7px 10px', background: '#0d1117', border: '1px solid #30363d', borderRadius: 8, color: '#e6edf3', fontSize: 13, boxSizing: 'border-box' }} /></div>
                <button onClick={() => { setShowCustom(false); setPage(0) }} style={{ padding: '8px', background: '#238636', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Aplicar</button>
              </div>
            </div>
          )}
        </div>

        <Dropdown label={typeFilter === 'all' ? 'Todas' : typeFilter === 'credit' ? 'Receitas' : 'Despesas'} icon={<Filter style={{ width: 13, height: 13, color: '#8b949e' }} />}>
          <DropdownItem label="Todas" active={typeFilter === 'all'} onClick={() => { setTypeFilter('all'); setPage(0) }} />
          <DropdownItem label="Receitas" active={typeFilter === 'credit'} onClick={() => { setTypeFilter('credit'); setPage(0) }} />
          <DropdownItem label="Despesas" active={typeFilter === 'debit'} onClick={() => { setTypeFilter('debit'); setPage(0) }} />
        </Dropdown>

        {accounts.length > 0 && (
          <Dropdown label={accountFilter === 'all' ? 'Todas Contas' : (accountsMap[accountFilter] ?? 'Conta')}>
            <DropdownItem label="Todas as contas" active={accountFilter === 'all'} onClick={() => { setAccountFilter('all'); setPage(0) }} />
            {accounts.map(a => <DropdownItem key={a.id} label={a.bank_name} active={accountFilter === a.id} onClick={() => { setAccountFilter(a.id); setPage(0) }} />)}
          </Dropdown>
        )}

        {categories.length > 0 && (
          <Dropdown label={categoryFilter === 'all' ? 'Categorias' : categoryFilter} icon={<SlidersHorizontal style={{ width: 13, height: 13, color: '#8b949e' }} />}>
            <DropdownItem label="Todas categorias" active={categoryFilter === 'all'} onClick={() => { setCategoryFilter('all'); setPage(0) }} />
            {categories.map(c => <DropdownItem key={c} label={c} active={categoryFilter === c} onClick={() => { setCategoryFilter(c); setPage(0) }} />)}
          </Dropdown>
        )}

        <Dropdown label={SORT_LABELS[sortKey]}>
          {(Object.keys(SORT_LABELS) as SortKey[]).map(k => <DropdownItem key={k} label={SORT_LABELS[k]} active={sortKey === k} onClick={() => setSortKey(k)} />)}
        </Dropdown>

        {hasFilters && (
          <button onClick={() => { setTypeFilter('all'); setAccountFilter('all'); setCategoryFilter('all'); setSearch(''); setPage(0) }}
            style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', background: '#2d1b1b', border: '1px solid #7f1d1d', borderRadius: 8, color: '#ef4444', fontSize: 12, cursor: 'pointer' }}>
            <X style={{ width: 12, height: 12 }} /> Limpar filtros
          </button>
        )}
      </div>

      {/* Table */}
      <div style={{ background: '#0d1117', border: '1px solid #21262d', borderRadius: 16, overflow: 'hidden', marginBottom: 16 }}>
        {/* Header row */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1.2fr 1fr 0.7fr 1fr 36px', padding: '10px 20px', borderBottom: '1px solid #21262d', background: '#161b22' }}>
          {['DESCRIÇÃO', 'CATEGORIA', 'CONTA', 'DATA', 'VALOR', ''].map((h, i) => (
            <span key={i} style={{ fontSize: 10, fontWeight: 700, color: '#484f58', letterSpacing: '0.06em', textAlign: i >= 4 ? 'right' : 'left' }}>{h}</span>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div style={{ padding: '60px 20px', textAlign: 'center' }}>
            <p style={{ color: '#484f58', fontSize: 14 }}>Nenhuma transação encontrada para os filtros selecionados.</p>
          </div>
        ) : (
          grouped.map(([date, txs]) => (
            <div key={date}>
              {/* Date group header */}
              <div style={{ padding: '8px 20px', background: '#0d1117', borderBottom: '1px solid #161b22', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#8b949e', textTransform: 'capitalize' }}>
                  {new Date(`${date}T00:00:00`).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
                </span>
                <span style={{ fontSize: 11, color: '#484f58' }}>
                  {txs.length} {txs.length === 1 ? 'transação' : 'transações'} ·{' '}
                  <span style={{ color: txs.reduce((s, t) => s + (t.type === 'debit' ? -1 : 1) * Math.abs(Number(t.amount)), 0) >= 0 ? '#10b981' : '#f87171', fontWeight: 600 }}>
                    {showValues ? fmt(Math.abs(txs.reduce((s, t) => s + (t.type === 'debit' ? -1 : 1) * Math.abs(Number(t.amount)), 0))) : '••••'}
                  </span>
                </span>
              </div>

              {txs.map(t => {
                const catColor = getCatColor(t.category)
                return (
                  <div key={t.id} onClick={() => setSelectedTx(t)}
                    style={{ display: 'grid', gridTemplateColumns: '2fr 1.2fr 1fr 0.7fr 1fr 36px', padding: '12px 20px', borderBottom: '1px solid #161b22', cursor: 'pointer', alignItems: 'center', transition: 'background 0.1s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#161b22')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                      <div style={{ width: 32, height: 32, borderRadius: 8, background: t.type === 'credit' ? '#064e3b' : '#2d1b1b', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {t.type === 'credit' ? <ArrowUpRight style={{ width: 14, height: 14, color: '#10b981' }} /> : <ArrowDownRight style={{ width: 14, height: 14, color: '#ef4444' }} />}
                      </div>
                      <div style={{ minWidth: 0 }}>
                        <p style={{ fontSize: 13, fontWeight: 500, color: '#e6edf3', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.description}</p>
                        {t.is_manual && <span style={{ fontSize: 10, color: '#484f58', background: '#21262d', padding: '1px 6px', borderRadius: 4 }}>Manual</span>}
                      </div>
                    </div>

                    <div>
                      {t.category ? (
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 500, padding: '3px 8px', borderRadius: 20, background: `${catColor}18`, color: catColor, border: `1px solid ${catColor}35` }}>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: catColor, display: 'inline-block' }} />
                          {t.category}
                        </span>
                      ) : <span style={{ fontSize: 12, color: '#30363d' }}>—</span>}
                    </div>

                    <div>
                      <span style={{ fontSize: 12, color: '#8b949e', background: '#161b22', padding: '2px 8px', borderRadius: 6, border: '1px solid #21262d' }}>
                        {accountsMap[t.account_id] ?? '—'}
                      </span>
                    </div>

                    <p style={{ fontSize: 12, color: '#484f58', textAlign: 'right' }}>
                      {new Date(`${t.date}T00:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                    </p>

                    <p style={{ fontSize: 13, fontWeight: 700, textAlign: 'right', color: t.type === 'credit' ? '#10b981' : '#f87171' }}>
                      {t.type === 'credit' ? '+' : '-'}{showValues ? fmt(Number(t.amount)) : '•••••'}
                    </p>

                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <MoreVertical style={{ width: 14, height: 14, color: '#30363d' }} />
                    </div>
                  </div>
                )
              })}
            </div>
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <p style={{ fontSize: 12, color: '#484f58' }}>
            {page * LIMIT + 1}–{Math.min((page + 1) * LIMIT, filtered.length)} de {filtered.length}
          </p>
          <div style={{ display: 'flex', gap: 4 }}>
            {[
              { label: '«', action: () => setPage(0), disabled: page === 0 },
              { label: <ChevronLeft style={{ width: 14, height: 14 }} />, action: () => setPage(p => p - 1), disabled: page === 0 },
            ].map((btn, i) => (
              <button key={i} onClick={btn.action} disabled={btn.disabled}
                style={{ padding: '6px 10px', background: '#161b22', border: '1px solid #30363d', borderRadius: 6, color: btn.disabled ? '#30363d' : '#e6edf3', fontSize: 12, cursor: btn.disabled ? 'not-allowed' : 'pointer' }}>
                {btn.label}
              </button>
            ))}
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              const p = totalPages <= 5 ? i : Math.min(Math.max(page - 2 + i, 0), totalPages - 5 + i)
              return (
                <button key={p} onClick={() => setPage(p)}
                  style={{ padding: '6px 12px', background: page === p ? '#238636' : '#161b22', border: `1px solid ${page === p ? '#2ea043' : '#30363d'}`, borderRadius: 6, color: page === p ? '#fff' : '#8b949e', fontSize: 12, cursor: 'pointer', fontWeight: page === p ? 700 : 400 }}>
                  {p + 1}
                </button>
              )
            })}
            {[
              { label: <ChevronRight style={{ width: 14, height: 14 }} />, action: () => setPage(p => p + 1), disabled: page >= totalPages - 1 },
              { label: '»', action: () => setPage(totalPages - 1), disabled: page >= totalPages - 1 },
            ].map((btn, i) => (
              <button key={i} onClick={btn.action} disabled={btn.disabled}
                style={{ padding: '6px 10px', background: '#161b22', border: '1px solid #30363d', borderRadius: 6, color: btn.disabled ? '#30363d' : '#e6edf3', fontSize: 12, cursor: btn.disabled ? 'not-allowed' : 'pointer' }}>
                {btn.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedTx && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }} onClick={() => setSelectedTx(null)}>
          <div style={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 16, padding: 28, width: 420, maxWidth: '90vw' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: selectedTx.type === 'credit' ? '#064e3b' : '#2d1b1b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {selectedTx.type === 'credit' ? <ArrowUpRight style={{ width: 20, height: 20, color: '#10b981' }} /> : <ArrowDownRight style={{ width: 20, height: 20, color: '#ef4444' }} />}
                </div>
                <div>
                  <p style={{ fontWeight: 700, color: '#e6edf3', fontSize: 16 }}>Detalhes da Transação</p>
                  <p style={{ fontSize: 12, color: '#484f58' }}>{selectedTx.type === 'credit' ? 'Receita' : 'Despesa'}</p>
                </div>
              </div>
              <button onClick={() => setSelectedTx(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#484f58', padding: 4 }}>
                <X style={{ width: 20, height: 20 }} />
              </button>
            </div>
            <p style={{ fontSize: 34, fontWeight: 800, color: selectedTx.type === 'credit' ? '#10b981' : '#f87171', marginBottom: 20 }}>
              {selectedTx.type === 'credit' ? '+' : '-'}{showValues ? fmt(Number(selectedTx.amount)) : '•••••'}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {[
                ['Descrição', selectedTx.description],
                ['Data', new Date(`${selectedTx.date}T00:00:00`).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })],
                ['Categoria', selectedTx.category ?? 'Outros'],
                ['Conta', accountsMap[selectedTx.account_id] ?? 'N/A'],
                ['Método', selectedTx.payment_method ?? 'N/A'],
                ['Origem', selectedTx.is_manual ? 'Manual' : 'Pluggy · Open Finance'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '11px 0', borderBottom: '1px solid #21262d' }}>
                  <span style={{ fontSize: 13, color: '#484f58' }}>{label}</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: '#e6edf3', textAlign: 'right', maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  )
}
